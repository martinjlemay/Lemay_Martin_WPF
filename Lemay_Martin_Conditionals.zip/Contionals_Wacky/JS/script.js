/**
 * Created by Martin Lemay on 6/19/14. Conditionals_Wacky
 */


// Starting a snow blower
var chokePushed = prompt("Push in ")
var chokePulled = prompt("Pull the choke. Is Choke on? \'yes\' or \'no\'");
var ropePulled = prompt("Pull the rope. Did you pull rope? \'yes\' or \'no\'");
var snowBlowerRun = prompt("Did snow blower start? \'yes\' or \'no\'");
var runRough = prompt("Is snow blower running rough? \'yes\' or \'no\'");

if (chokePulled == "yes"){
    prompt(ropePulled)
}else{ prompt(chokePulled);
    if (ropePulled == "yes"){
        prompt(snowBlowerRun);
    }else{prompt(ropePulled)
    }
    }
        if (snowBlowerRun == "yes"){
            prompt(runRough);
            if (runRough == "yes"){




            }else if (runRough == "no"){ console.log("Leave choke pulled out")
                }
        }else{prompt(ropePulled)
        }


}